var dlugoscFormularza;
var gematriaFormularz;
var nouseFormularz;
var psycheFormularz;
var somaFormularz;
var cyklFormularz;
var rodzaj;
var odRodzaj;
var doRodzaj;
var tablicaPoprawne = [];
var tablicaDuplikaty = [];
var kombinacje = [];
var wyswietl = false;
var stanGematria = false;
var stanNouse = false;
var stanPsyche = false;
var stanSoma = false;
var stanKonkretJak;
var stanCyklDowolnosc = false;
var stanCyklDowolnoscDodatnosc = false;
var stanCyklDowolnoscUjemnosc = false;
var stanCyklStagnacja = false;
var stanCyklKonkret = false;
var stanKonkretOd = 0;
var stanKonkretDo = 0;
var gdzieCykl = 0;
var zeroGematria = false;
var zeroNouse = false;
var zeroPsyche = false;
var zeroSoma = false;
var wyswietl = false;
var slowaID = document.getElementById("slowa");
var ile = 0;
const table_numbers = [
    11, 22, 33, 44, 55, 66, 77, 88, 217, 99, 111, 222, 333, 444, 555, 666, 777, 888, 999, 1111, 2222, 28, 496, 8128,15,17,23,166,266,366,466,566,766,866,966,616,626,636,646,656,676,686,696,660,661,662,663,664,665,667,668,669
];
var nous = new Array(26).fill(0);
var psyche = new Array(26).fill(0);
var soma = new Array(26).fill(0);
var gematric = new Array(26).fill(0);
var gen = document.getElementById("gen");
var somal = 0;
var gematricl = 0;
const alphabetSize = 26;
const polishAlphabet = Array.from({ length: alphabetSize }, (_, i) => String.fromCharCode('a'.charCodeAt(0) + i));

for (let i = 0; i < alphabetSize; i++) {
    if (somal === 9) {
        somal = 0;
    }
    if (gematricl <= 9) {
        gematricl++;
    } else if (gematricl >= 10 && gematricl < 100) {
        gematricl = gematricl + 10;
    } else if (gematricl >= 100) {
        gematricl = gematricl + 100;
    }
    nous[i] = 100 + i;
    psyche[i] = i + 1;
    somal++;
    soma[i] = somal;
    gematric[i] = gematricl;
}

document.getElementById("przycisk").addEventListener('click', () => {
    //console.log("Kliknięto przycisk"); // Debugowanie: sprawdzenie, czy przycisk jest klikany
    pobierzDane();
});

function pobierzDane() {
    dlugoscFormularza = document.getElementById("dlugosc").value;
    gematriaFormularz = document.getElementById("gematric").value;
    nouseFormularz = document.getElementById("nouse").value;
    psycheFormularz = document.getElementById("psyche").value;
    somaFormularz = document.getElementById("soma").value;
    cyklFormularz = document.getElementById("cykl").value;

    var error = "";

    rodzaj = Number(cyklFormularz.charAt(0));
    odRodzaj = Number(cyklFormularz.charAt(1));
    doRodzaj = Number(cyklFormularz.charAt(2));

    if (Number(gematriaFormularz) == -1) {
        stanGematria = true;
        zeroGematria = false;
    } else if (Number(gematriaFormularz) == -2) {
        stanGematria = false;
        zeroGematria = true;
    } else if (Number(gematriaFormularz) >= 1) {
        stanGematria = false;
        zeroGematria = false;
    }
        
    if (Number(nouseFormularz) == -1) {
        stanNouse = true;
        zeroNouse = false;
    } else if (Number(nouseFormularz) == -2) {
        stanNouse = false;
        zeroNouse = true;
    } else if (Number(nouseFormularz) >= 1) {
        stanNouse = false;
        zeroNouse = false;
    }
        
    if (Number(psycheFormularz) == -1) {
        stanPsyche = true;
        zeroPsyche = false;
    } else if (Number(psycheFormularz) == -2) {
        stanPsyche = false;
        zeroPsyche = true;
    } else if (Number(psycheFormularz) >= 1) {
        stanPsyche = false;
        zeroPsyche = false;
    }
        
    if (Number(somaFormularz) == -1) {
        stanSoma = true;
        zeroSoma = false;
    } else if (Number(somaFormularz) == -2) {
        stanSoma = false;
        zeroSoma = true;
    } else if (Number(somaFormularz) >= 1) {
        stanSoma = false;
        zeroSoma = false;
    }
        
    if (Number(cyklFormularz) == -1) {
        stanCyklDowolnosc = true;
        stanCyklDowolnoscDodatnosc = false;
        stanCyklDowolnoscUjemnosc = false;
        stanCyklStagnacja = false;
        stanCyklKonkret = false;
    } else if (Number(cyklFormularz) == -2) {
        stanCyklDowolnosc = false;
        stanCyklDowolnoscDodatnosc = true;
        stanCyklDowolnoscUjemnosc = false;
        stanCyklStagnacja = false;
        stanCyklKonkret = false;
    } else if (Number(cyklFormularz) == -3) {
        stanCyklDowolnosc = false;
        stanCyklDowolnoscDodatnosc = false;
        stanCyklDowolnoscUjemnosc = false;
        stanCyklStagnacja = true;
        stanCyklKonkret = false;
    } else if (Number(cyklFormularz) == -4) {
        stanCyklDowolnosc = false;
        stanCyklDowolnoscDodatnosc = false;
        stanCyklDowolnoscUjemnosc = true;
        stanCyklStagnacja = false;
        stanCyklKonkret = false;
    } else if (Number(cyklFormularz) >= 1) {
        stanCyklDowolnosc = false;
        stanCyklDowolnoscDodatnosc = false;
        stanCyklDowolnoscUjemnosc = false;
        stanCyklStagnacja = false;
        stanCyklKonkret = true;
        stanKonkretJak = cyklFormularz.toString().charAt(0); 
        stanKonkretOd = cyklFormularz.toString().charAt(1); 
        stanKonkretDo = cyklFormularz.toString().charAt(2);
        
        if(stanKonkretJak == 1) {
            gdzieCykl = 1;
        }
        if(stanKonkretJak == 2) {
            gdzieCykl = 2;
        }
        if(stanKonkretJak == 3) {
            gdzieCykl = 3;
        }
    }

    if (isNaN(dlugoscFormularza) || dlugoscFormularza <= 0) {
        error += "ile: liczba ma być większa od zera.\n";
    }

    if(rodzaj < 0 || rodzaj > 2){
        error += "rodzaj: rodzaj ma się składać z 0d 0 do 2 \n";
    }

    if(odRodzaj < doRodzaj  && rodzaj == 0 ){
        error += "zakres updakowy: błędne dane drugiego składnika  \n";
    }

    if(odRodzaj != doRodzaj  && rodzaj == 1 ){
        error += "zakres stagnacyjny: błędne dane drugiego składnika  \n";
    }

    if(odRodzaj > doRodzaj  && rodzaj == 2 ){
        error += "zakres wzrostowy: błędne dane drugiego składnika  \n";
    }

    if(error !== ""){
        alert(error);
        error = "";
        return;
    }
    gen.innerHTML = "wolamy";
    generujKombinacje(parseInt(dlugoscFormularza));  // Upewnij się, że to liczba całkowita
}

var n = 0;

function generujKombinacje(maxDlugosc) {
    console.log("Rozpoczynanie generowania kombinacji...");
   
    const alfabet = 'abcdefghijklmnopqrstuvwxyz';
    const alfabetLength = alfabet.length;

    // Tablica, która przechowuje aktualne indeksy
    let kombinacja = Array(maxDlugosc).fill(0);  // Wstępnie wypełniona zerami

    // Dopóki nie dojdziemy do końca, generujemy kombinacje
    while (true) {
        // Tworzymy ciąg na podstawie aktualnej kombinacji
        let str = '';
        for (let i = 0; i < maxDlugosc; i++) {
            str += alfabet[kombinacja[i]];
        }

        // Natychmiast wysyłamy ciąg do kalkulatora
        kalkulator(str);  // Wywołanie funkcji kalkulator

        // Szukamy miejsca do inkrementacji
        let i = maxDlugosc - 1;
        while (i >= 0) {
            if (kombinacja[i] < alfabetLength - (maxDlugosc - i)) {
                kombinacja[i]++;  // Inkrementacja
                // Resetujemy wszystkie indeksy po i
                for (let j = i + 1; j < maxDlugosc; j++) {
                    kombinacja[j] = kombinacja[j - 1] + 1;
                }
                break;
            } else {
                i--;  // Przechodzimy do poprzedniego indeksu
            }
        }

        // Jeśli wszystkie kombinacje zostały wygenerowane, kończymy
        if (i < 0) break;
    }

    console.log("Generowanie zakończone.");
    gen.innerHTML = "powolanie";
}

function kalkulator(txt){
    var how_many = txt.length;
    var letter = "";
    var znalezienieGematric = false;
    var znalezienieNouse = false;
    var znalezieniePsyche = false;
    var znalezienieSoma = false;
    var cyklTrue = false;
    var finalGematric = 0;
    var finalNouse = 0;
    var finalPsyche = 0;
    var finalSoma = 0;
    var suma_gematric = 0;
    var suma_nous = 0;
    var suma_psyche = 0;
    var suma_soma = 0;
    var suma_gematric2 = 0;
    var suma_nous2 = 0;
    var suma_psyche2 = 0;
    var suma_soma2 = 0;
    var suma_gematric3 = 0;
    var suma_nous3 = 0;
    var suma_psyche3 = 0;
    var suma_soma3 = 0;
    var textSlowa = "";
    var finalCyklOd = 0;
    var finalCyklDo = 0;
    var finalCyklRodzaj = "";
    var waga2 = 0;
    var waga = 0;
    var what = [0, 0, 0, 0, 0, 0, 0, 0];
    var g = "";
    var n = "";
    var p = "";
    var s = "";
    var gg = "";
    var nn = "";
    var pp = "";
    var ss = "";
    var wynikT = "";

    for(let i = 0;i<how_many;i++){
        letter = txt.charAt(i).toLowerCase();
        const j = polishAlphabet.indexOf(letter);
        waga = j;
        if (j !== -1) {
            suma_nous += nous[j];
            suma_psyche += psyche[j];
            suma_soma += soma[j];
            suma_gematric += gematric[j];
            //console.log(txt[i], gematric[j], nous[j], psyche[j], soma[j]);
            if (i === 0 && waga2 === 0) {
                waga2 = soma[j];
            }
        }

        waga = soma[j];
    }

        if (what[0] === 0) {
                //jak nie jest znaleziony znak
                if(!znalezienieGematric){
                    if(stanGematria){
                        //dowolne wartosc mocy
                        for(let i = 0;i<table_numbers.length;i++){
                            if (suma_gematric === table_numbers[i]) {
                                what[0] = 1;
                                finalGematric = suma_gematric;
                                znalezienieGematric = true;
                            }
                        }
                    }else if(zeroGematria){
                        //dowolne wartosc
                        finalGematric = suma_gematric;
                       for(let i = 0;i<table_numbers.length;i++){
                        if (suma_gematric === table_numbers[i]) {
                            what[0] = 1;
                            znalezienieGematric = true;
                        }
                    }
                    }else{
                        //konkret
                        if (suma_gematric == parseInt(gematriaFormularz)) {
                                what[0] = 1;
                                finalGematric = suma_gematric;
                                znalezienieGematric = true;
                            }
                    }
                }
            }        
               //jak nie jest znaleziony znak
                if(!znalezienieNouse){
                    if(stanNouse){    
                        //dowolne wartosc mocy
                        for(let i = 0;i<table_numbers.length;i++){
                            if (suma_nous == table_numbers[i]) {
                                what[1] = 1;
                                finalNouse = suma_nous;
                                znalezienieNouse = true;
                            }
                        }
                    }else if(zeroNouse){
                        //dowolne wartosc
                        finalNouse = suma_nous;
                       for(let i = 0;i<table_numbers.length;i++){
                        if (suma_nous === table_numbers[i]) {
                            what[1] = 1;
                            znalezienieNouse = true;
                        }
                    }
                    }else{
                        //konkret
                        if (suma_nous == parseInt(nouseFormularz)) {
                                what[1] = 1;
                                finalNouse = suma_nous;
                                znalezienieNouse = true;
                            }
                    }
                }

        if(!znalezieniePsyche){
            if(stanPsyche){
                //dowolne wartosc mocy
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_psyche === table_numbers[i]) {
                        what[2] = 1;
                        finalPsyche = suma_psyche;
                        znalezieniePsyche = true;
                    }
                }
            }else if(zeroPsyche){
                //dowolne wartosc
                finalPsyche = suma_psyche;
               for(let i = 0;i<table_numbers.length;i++){
                if (suma_psyche === table_numbers[i]) {
                    what[2] = 1;
                    znalezieniePsyche = true;
                }
            } 
            }else{
                //konkret
                if (suma_psyche == parseInt(psycheFormularz)) {
                        what[2] = 1;
                        finalPsyche = suma_psyche;
                        znalezieniePsyche = true;
                    }
            }
        }

        if(!znalezienieSoma){
            if(stanSoma){
                //dowolne wartosc mocy
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_soma === table_numbers[i]) {
                        what[3] = 1;
                        finalSoma = suma_soma;
                        znalezienieSoma = true;
                    }
                }  
            }else if(zeroSoma){
                finalSoma = suma_soma;
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_soma === table_numbers[i]) {
                        what[3] = 1;  
                    }
                } 
            }else{
                //konkret
                if (suma_soma == parseInt(somaFormularz)) {
                        what[3] = 1;
                        finalSoma = suma_soma;
                        znalezienieSoma = true;
                       // alert("konkret "+finalGematric+" "+txt);  
                       //wynikT += " soma "+suma_soma; 
                    }
                    
            }
        }         
    
     g = suma_gematric.toString();
     n = suma_nous.toString();
     p = suma_psyche.toString();
     s = suma_soma.toString();
     
    
    if (what[0] === 0) {
        if (g.length > 1) {
            for (let i = 0; i < g.length; i++) {
                const str = g[i];
                const pomoc = +str;
                suma_gematric2 = suma_gematric2 + pomoc;
            }
        }
    }
    
    if (what[1] === 0) {
        if (n.length > 1) {
            for (let i = 0; i < n.length; i++) {
                const str1 = n[i];
                const pomoc1 = +str1;
                suma_nous2 = suma_nous2 + pomoc1;
            }
        }
    }
    
    if (what[2] === 0) {
        if (p.length > 1) {
            for (let i = 0; i < p.length; i++) {
                const str2 = p[i];
                const pomoc2 = +str2;
                suma_psyche2 = suma_psyche2 + pomoc2;
            }
        }
    }
    
    if (what[3] === 0) {
        if (s.length > 1) {
            for (let i = 0; i < s.length; i++) {
                const str3 = s[i];
                const pomoc3 = +str3;
                suma_soma2 = suma_soma2 + pomoc3;
            }
        }
    }

    
            //jak nie jest znaleziony znak
            if(!znalezienieGematric){
                if(stanGematria){
                    //dowolne wartosc mocy
                    for(let i = 0;i<table_numbers.length;i++){
                        if (suma_gematric2 === table_numbers[i]) {
                            finalGematric = suma_gematric2;
                            znalezienieGematric = true;
                            what[4] = 1;
                        }
                    }
                }else if(zeroGematria){
                    if(g.length > 1){
                        finalGematric = suma_gematric2;
                        for(let i = 0;i<table_numbers.length;i++){
                            if (suma_gematric2 === table_numbers[i]) {
                                what[4] = 1;
                                znalezienieGematric = true;
                            }
                        }
                    }else{
                        finalGematric = suma_gematric;
                    }   
                }else{
                    //konkret
                    if (suma_gematric2 == parseInt(gematriaFormularz)) {
                            finalGematric = suma_gematric2;
                            znalezienieGematric = true;
                            what[4] = 1;
                        }
                }
            }
            //jak nie jest znaleziony znak
            if(!znalezienieNouse){
                if(stanNouse){
                    //dowolne wartosc mocy
                    for(let i = 0;i<table_numbers.length;i++){
                        if (suma_nous2 == table_numbers[i]) {
                            what[5] = 1;
                            finalNouse = suma_nous2;
                            znalezienieNouse = true;
                        }
                    }
                }else if(zeroNouse){
                   if(n.length > 1){
                        finalNouse = suma_nous2;
                        for(let i = 0;i<table_numbers.length;i++){
                            if (suma_nous2 === table_numbers[i]) {
                                what[5] = 1;
                                znalezienieNouse = true;
                            }
                        }
                   }else{
                    finalNouse = suma_nous;
                   }
                }else{
                    //konkret
                    if (suma_nous2 == parseInt(nouseFormularz)) {
                            what[5] = 1;
                            finalNouse = suma_nous2;
                            znalezienieNouse = true;
                        }
                }
            }
        
    if(!znalezieniePsyche){
        if(stanPsyche){
            //dowolne wartosc mocy
            for(let i = 0;i<table_numbers.length;i++){
                if (suma_psyche2 === table_numbers[i]) {
                    what[6] = 1;
                    finalPsyche = suma_psyche2;
                    znalezieniePsyche = true;
                }
            }
        }else if(zeroPsyche){
            if(p.length > 1){
                finalPsyche = suma_psyche2;
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_psyche2 === table_numbers[i]) {
                        what[6] = 1;
                        znalezieniePsyche = true;
                    }
                }
            }else{
                finalPsyche = suma_psyche;
            }
        }else{
            //konkret
            if (suma_psyche2 == parseInt(psycheFormularz)) {
                    what[6] = 1;
                    finalPsyche = suma_psyche2;
                    znalezieniePsyche = true;
                }
        }
    }

    if(!znalezienieSoma){
        if(stanSoma){
            //dowolne wartosc mocy
            for(let i = 0;i<table_numbers.length;i++){
                if (suma_soma2 === table_numbers[i]) {
                    what[7] = 1;
                    finalSoma = suma_soma2;
                    znalezienieSoma = true;
                }
            }
        }else if(zeroSoma){
            if(s.length > 1){
                finalSoma = suma_soma2;
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_soma2 === table_numbers[i]) {
                        what[7] = 1;
                        znalezienieSoma = true;
                    }
                }
            }else{
                finalSoma = suma_soma;
            }   
        }else{
            //konkret
            if (suma_soma2 == parseInt(somaFormularz)) {
                    what[7] = 1;
                    finalSoma = suma_soma2;
                    znalezienieSoma = true;
                }
        }
    }

    
     gg = suma_gematric2.toString();
     nn = suma_nous2.toString();
     pp = suma_psyche2.toString();
     ss = suma_soma2.toString();
  
  if (what[4] === 0) {
      if (gg.length > 1) {
          for (let i = 0; i < gg.length; i++) {
              const str4 = gg[i];
              const pomoc4 = +str4;
              suma_gematric3 = suma_gematric3 + pomoc4;
          }

          if(!znalezienieGematric){
            if(stanGematria){
                //dowolne wartosc mocy
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_gematric3 === table_numbers[i]) {
                        finalGematric = suma_gematric3;
                        znalezienieGematric = true;
                    }
                }
            }else if(zeroGematria){
                //dowolne wartosc
                finalGematric = suma_gematric3;
                wyswietl = true;
            }else{
                //konkret
                if (parseInt(suma_gematric3) == parseInt(gematriaFormularz)) {
                        finalGematric = suma_gematric3;
                        znalezienieGematric = true;
                    }
            }
        }

      }
  }
  
  if (what[5] === 0) {
      if (nn.length > 1) {
          for (let i = 0; i < nn.length; i++) {
              const str5 = nn[i];
              const pomoc5 = +str5;
              suma_nous3 = suma_nous3 + pomoc5;
          }

          if(!znalezienieNouse){
            if(stanNouse){
                //dowolne wartosc mocy
                for(let i = 0;i<table_numbers.length;i++){
                    if (suma_nous3 == table_numbers[i]) {
                        finalNouse = suma_nous3;
                        znalezienieNouse = true;
                    }
                }
            }else if(zeroNouse){
                //dowolne wartosc
                finalNouse = suma_nous3;
                wyswietl = true;
            }else{
                
                //konkret
                if (suma_nous3 == parseInt(nouseFormularz)) {
                        finalNouse = suma_nous3;
                        znalezienieNouse = true;
                    }
            }
        }
        
      }
  }
  
  if (what[6] === 0) {
      if (pp.length > 1) {
          for (let i = 0; i < pp.length; i++) {
              const str6 = pp[i];
              const pomoc6 = +str6;
              suma_psyche3 = suma_psyche3 + pomoc6;
          }

          if(!znalezieniePsyche){
            if(stanPsyche){
            //dowolne wartosc mocy
            for(let i = 0;i<table_numbers.length;i++){
                if (suma_psyche3 === table_numbers[i]) {
                    //what[6] = 1;
                    finalPsyche = suma_psyche3;
                    znalezieniePsyche = true;
                }
            }
            }else if(zeroPsyche){
            //dowolne wartosc
            finalPsyche = suma_psyche3;
            wyswietl = true; 
            }else{
            //konkret
            if (suma_psyche3 == parseInt(psycheFormularz)) {
                    //what[6] = 1;
                    finalPsyche = suma_psyche3;
                    znalezieniePsyche = true;
                }
            }
        
            }
      }
  }
  
  if (what[7] === 0) {
      if (ss.length > 1) {
          for (let i = 0; i < ss.length; i++) {
              const str7 = ss[i];
              const pomoc7 = +str7;
              suma_soma3 = suma_soma3 + pomoc7;
          }

          if(!znalezienieSoma){
            if(stanSoma){
            //dowolne wartosc mocy
            for(let i = 0;i<table_numbers.length;i++){
                if (suma_soma3 === table_numbers[i]) {
                    finalSoma = suma_soma3;
                    znalezienieSoma = true;                  
                }
            }
            }else if(zeroSoma){
            //dowolne wartosc
            finalSoma = suma_soma3;  
            }else{
            //konkret
            if (suma_soma3 == parseInt(somaFormularz)) {
                    // /what[7] = 1;
                    finalSoma = suma_soma3;
                    znalezienieSoma = true;
                }
            }
            }
        
      }
  }
    
  finalCyklOd = waga2;
  finalCyklDo = soma[waga-1];

if(cyklFormularz == -1){
    if (finalCyklOd < finalCyklDo ) {finalCyklRodzaj = " rosnący od "+finalCyklOd+" do "+finalCyklDo;}
    if (finalCyklOd > finalCyklDo) {finalCyklRodzaj = " updakowy "+finalCyklOd+" do "+finalCyklDo;}
    if (finalCyklOd == finalCyklDo) {finalCyklRodzaj = " stagnacyjny "+finalCyklOd+" do "+finalCyklDo;}
    cyklTrue = true;
}else if(cyklFormularz == -2){
    if (finalCyklOd < finalCyklDo ) {
        finalCyklRodzaj = " rosnący od "+finalCyklOd+" do "+finalCyklDo;
        cyklTrue = true;
    }
}else if(cyklFormularz == -3){
    if (finalCyklOd == finalCyklDo) {
        finalCyklRodzaj = " stagnacyjny od "+finalCyklOd+" do "+finalCyklDo;
        cyklTrue = true;
    }
}else if(cyklFormularz == -4){
    if (finalCyklOd > finalCyklDo) {
        finalCyklRodzaj = " updakowy od "+finalCyklOd+" do "+finalCyklDo;
        cyklTrue = true;
    }
}else{
    if(parseInt(stanKonkretJak) == 0){
        if(parseInt(stanKonkretOd) == finalCyklOd && parseInt(stanKonkretDo) == finalCyklDo){
            finalCyklRodzaj = " updakowy od "+finalCyklOd+" do "+finalCyklDo;
            cyklTrue = true;
        }
    } else if(parseInt(stanKonkretJak) == 1){
        if(parseInt(stanKonkretOd) == finalCyklOd && parseInt(stanKonkretDo) == finalCyklDo){
            finalCyklRodzaj = " stagnacyjny od "+finalCyklOd+" do "+finalCyklDo;
            cyklTrue = true;
        }
    }else if(parseInt(stanKonkretJak) == 2){
        if(parseInt(stanKonkretOd) == finalCyklOd && parseInt(stanKonkretDo) == finalCyklDo){
            finalCyklRodzaj = " rosnący od "+finalCyklOd+" do "+finalCyklDo;
            cyklTrue = true;
        }
    }
}

  if(finalGematric >= 1 && finalNouse >= 1 && finalPsyche >= 1  && finalSoma >= 1 && cyklTrue){
    ile++;
    //console.log(` ${ile} ${txt} gematric ${finalGematric} nouse ${finalNouse} psyche ${finalPsyche} soma ${finalSoma} cykl ${finalCyklRodzaj}`);
    textSlowa = "";
    textSlowa = `<p>${txt} ${ile}  gematric ${finalGematric} nouse ${finalNouse} psyche ${finalPsyche} soma ${finalSoma} cykl ${finalCyklRodzaj}</p>`;
    //slowaID.insertAdjacentHTML("beforeend", `<p>${txt} ${ile}  gematric ${finalGematric} nouse ${finalNouse} psyche ${finalPsyche} soma ${finalSoma} cykl ${finalCyklRodzaj}</p>`);
    addRow(txt, ile, finalGematric, finalNouse, finalPsyche, finalSoma, finalCyklRodzaj)
    
}
}

function addRow(txt, ile, finalGematric, finalNouse, finalPsyche, finalSoma, finalCyklRodzaj) {
    const table = document.getElementById("slowaTable").querySelector("tbody");

    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${ile}</td>
        <td>${txt}</td>
        <td>${finalGematric}</td>
        <td>${finalNouse}</td>
        <td>${finalPsyche}</td>
        <td>${finalSoma}</td>
        <td>${finalCyklRodzaj}</td>
    `;

    table.appendChild(row); // Dodaj nowy wiersz do tabeli
}













