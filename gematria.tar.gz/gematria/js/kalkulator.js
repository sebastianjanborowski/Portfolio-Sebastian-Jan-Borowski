function calculateSums() 
{
  let waga2 = 0;
  let what = [0, 0, 0, 0, 0, 0, 0, 0];
  let suma_nous = 0;
  let suma_psyche = 0;
  let suma_soma = 0;
  let suma_gematric = 0;
  let somal = 0;
  let gematricl = 0;
  let nous = new Array(26).fill(0);
  let psyche = new Array(26).fill(0);
  let soma = new Array(26).fill(0);
  let gematric = new Array(26).fill(0);
  let suma_n = 0;
  let suma_e = 0;
  let suma_s = 0;
  let suma_g = 0;
  let waga = 0;
  let sumag = 0;
  let suman = 0;
  let sumas = 0;
  let sumap = 0;
  //const text = document.getElementById("tekst").value;
  const alphabetSize = 26;
  const how_many = text.length;
  const polishAlphabet = Array.from({ length: alphabetSize }, (_, i) => String.fromCharCode('a'.charCodeAt(0) + i));
  
  for (let i = 0; i < alphabetSize; i++) {
      if (somal === 9) {
          somal = 0;
      }
      if (gematricl <= 9) {
          gematricl++;
      } else if (gematricl >= 10 && gematricl < 100) {
          gematricl = gematricl + 10;
      } else if (gematricl >= 100) {
          gematricl = gematricl + 100;
      }
      nous[i] = 100 + i;
      psyche[i] = i + 1;
      somal++;
      soma[i] = somal;
      gematric[i] = gematricl;
  }
  
  for (let i = 0; i < how_many; i++) {
      const letter = text[i].toLowerCase();
      const j = polishAlphabet.indexOf(letter);
      waga = j;
      if (j !== -1) {
          suma_nous += nous[j];
          suma_psyche += psyche[j];
          suma_soma += soma[j];
          suma_gematric += gematric[j];
          //console.log(text[i], gematric[j], nous[j], psyche[j], soma[j]);
          if (i === 0 && waga2 === 0) {
              waga2 = soma[j];
          }
      }
  }
  
  const table_numbers = [
      11, 22, 33, 44, 55, 66, 77, 88, 99, 111, 222, 333, 444, 555, 666, 777, 888, 999, 1111, 2222, 6, 28, 496, 8128
  ];
  
  for (let i = 0; i < table_numbers.length; i++) {
      if (what[0] === 0) {
          if (suma_gematric === table_numbers[i]) {
              what[0] = 1;
          }
      }
      if (what[1] === 0) {
          if (suma_nous === table_numbers[i]) {
              what[1] = 1;
          }
      }
      if (what[2] === 0) {
          if (suma_psyche === table_numbers[i]) {
              what[2] = 1;
          }
      }
      if (what[3] === 0) {
          if (suma_soma === table_numbers[i]) {
              what[3] = 1;
          }
      }
  }
  
  let g = suma_gematric.toString();
  let n = suma_nous.toString();
  let p = suma_psyche.toString();
  let s = suma_soma.toString();
  const wynikElement = document.getElementById("wynik");const wynikElement1 = document.getElementById("wynik1");
  const wynikElement2 = document.getElementById("wynik2");const wynikElement3 = document.getElementById("wynik3");

  wynikElement.innerHTML = `Gematric1 - ${suma_gematric}`;wynikElement1.innerHTML = `Nous1 - ${suma_nous}`;
  wynikElement2.innerHTML = `Psyche1 - ${suma_psyche}`;wynikElement3.innerHTML = `Soma1 - ${suma_soma}`;


  if (what[0] === 0) {
      if (g.length > 1) {
          for (let i = 0; i < g.length; i++) {
              const str = g[i];
              const pomoc = +str;
              sumag = sumag + pomoc;
          }
          const wynikElement4 = document.getElementById("wynik4");
          wynikElement4.innerHTML = `Gematric2 - ${sumag}`;
      }
  }
  
  if (what[1] === 0) {
      if (n.length > 1) {
          for (let i = 0; i < n.length; i++) {
              const str1 = n[i];
              const pomoc1 = +str1;
              suman = suman + pomoc1;
          }
          const wynikElement5 = document.getElementById("wynik5");
          wynikElement5.innerHTML = `Nous2 - ${suman}`;
      }
  }
  
  if (what[2] === 0) {
      if (p.length > 1) {
          for (let i = 0; i < p.length; i++) {
              const str2 = p[i];
              const pomoc2 = +str2;
              sumap = sumap + pomoc2;
          }
          const wynikElement6 = document.getElementById("wynik6");
          wynikElement6.innerHTML = `Psyche2 - ${sumap}`;
      }
  }
  
  if (what[3] === 0) {
      if (s.length > 1) {
          for (let i = 0; i < s.length; i++) {
              const str3 = s[i];
              const pomoc3 = +str3;
              sumas = sumas + pomoc3;
          }
          const wynikElement7 = document.getElementById("wynik7");
          wynikElement7.innerHTML = `Soma2 - ${sumas}`;
      }
  }
  
  for (let i = 0; i < table_numbers.length; i++) {
      if (what[4] === 0) {
          if (sumag === table_numbers[i]) {
              what[4] = 1;
          }
      }
      if (what[5] === 0) {
          if (suman === table_numbers[i]) {
              what[5] = 1;
          }
      }
      if (what[6] === 0) {
          if (sumap === table_numbers[i]) {
              what[6] = 1;
          }
      }
      if (what[7] === 0) {
          if (sumas === table_numbers[i]) {
              what[7] = 1;
          }
      }
  }
  
  let gg = sumag.toString();
  let nn = suman.toString();
  let pp = sumap.toString();
  let ss = sumas.toString();
  
  if (what[4] === 0) {
      if (gg.length > 1) {
          for (let i = 0; i < gg.length; i++) {
              const str4 = gg[i];
              const pomoc4 = +str4;
              suma_g = suma_g + pomoc4;
          }
          const wynikElement8 = document.getElementById("wynik8");
          wynikElement8.innerHTML = `Gematric3 - ${suma_g}`;
      }
  }
  
  if (what[5] === 0) {
      if (nn.length > 1) {
          for (let i = 0; i < nn.length; i++) {
              const str5 = nn[i];
              const pomoc5 = +str5;
              suma_n = suma_n + pomoc5;
          }
          const wynikElement9 = document.getElementById("wynik9");
          wynikElement9.innerHTML = `Nous3 - ${suma_n}`;
      }
  }
  
  if (what[6] === 0) {
      if (pp.length > 1) {
          for (let i = 0; i < pp.length; i++) {
              const str6 = pp[i];
              const pomoc6 = +str6;
              suma_e = suma_e + pomoc6;
          }
          const wynikElement10 = document.getElementById("wynik10");
          wynikElement10.innerHTML = `Psyche3 - ${suma_e}`;
      }
  }
  
  if (what[7] === 0) {
      if (ss.length > 1) {
          for (let i = 0; i < ss.length; i++) {
              const str7 = ss[i];
              const pomoc7 = +str7;
              suma_s = suma_s + pomoc7;
          }
          const wynikElement11 = document.getElementById("wynik11");
          wynikElement11.innerHTML = `Soma3 - ${suma_s}`;
      }
  }
  const wynikElement12 = document.getElementById("wynik12");
  if (waga2 > soma[waga]) {
    wynikElement12.innerHTML = `Cykl malejący od  ${waga2} do ${soma[waga]}`;
  }
  
  if (waga2 < soma[waga]) {
    wynikElement12.innerHTML = `Cykl rosnący od  ${waga2} do ${soma[waga]}`;
  }
  
  if (waga2 === soma[waga]) {
    wynikElement12.innerHTML = `Cykl stagnacyjny od  ${waga2} do ${soma[waga]}`;
  }

  
  
  
}