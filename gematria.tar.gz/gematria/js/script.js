// Pobierz szerokość okna
var szerokosc = window.innerWidth;

// Pobierz elementy, z którymi będziesz pracować
var dlugosc = document.getElementById("dlugosc");
var labels = document.querySelectorAll('label');
var imie = document.getElementById("gematric");
var subName = document.getElementById("nouse");
var email = document.getElementById("psyche");
var password1 = document.getElementById("soma");
var password2 = document.getElementById("cykl");

// Funkcja zmieniająca style i placeholdery w zależności od szerokości okna
function updateUI() {
  if (szerokosc > 800) {
    // Większe okno, klasy "visibility" i usunięcie "Novisibility"
    labels.forEach(x => {
      x.classList.add('visibility');
      x.classList.remove('Novisibility');
    });

    // Resetowanie placeholderów
    dlugosc.placeholder = "";
    imie.placeholder = "";
    subName.placeholder = "";
    email.placeholder = "";
    password1.placeholder = "";
    password2.placeholder = "";
  }
  else {
    // Mniejsze okno, klasy "Novisibility" i usunięcie "visibility"
    labels.forEach(x => {
      x.classList.add('Novisibility');
      x.classList.remove('visibility');
    });

    // Ustawianie placeholderów
    dlugosc.placeholder = "ile"
    imie.placeholder = "gematric";
    subName.placeholder = "nous";
    email.placeholder = "psyche";
    password1.placeholder = "soma";
    password2.placeholder = "cykl";
  }
}

// Wywołaj funkcję przy załadowaniu strony
updateUI();

// Nasłuchiwanie na zmianę rozmiaru okna
window.addEventListener('resize', function() {
  // Za każdym razem, gdy rozmiar okna się zmienia, sprawdź ponownie
  szerokosc = window.innerWidth;
  updateUI();
});
